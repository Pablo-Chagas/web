<jsp:directive.page contentType="text/html; charset=UTF-8" />
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Posts - Facebook CRUD</title>
	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap-icons.css">
</head>
<body>

	<div class="container">
		<div class="row">
			<h2>Posts</h2>
			
			<a href="${pageContext.request.contextPath}/posts/form" class="btn btn-success mb-3">Novo Post</a>
			
			<table class="table table-striped">
				<thead>
					<tr>
						<th scope="col">Id</th>
						<th scope="col">Conteúdo</th>
						<th scope="col">Data</th>
						<!-- Coluna nova para os botões -->
						<th scope="col">Ações</th> 
					</tr>
				</thead>
				<tbody>
					<c:forEach var="post" items="${posts_list}">
						<tr>
							<th scope="row">${post.getId()}</th>
							<td>${post.getContent()}</td>
							<td>${post.getPostDate()}</td>
							<!-- Botão de Comentar adicionado aqui! -->
							<td>
								<a href="${pageContext.request.contextPath}/comments/form?post_id=${post.getId()}" class="btn btn-info btn-sm">? Comentar</a>
							</td>
						</tr>
					</c:forEach>
				</tbody>
			</table>
		</div>
	</div>

	<script src="${pageContext.request.contextPath}/js/bootstrap.bundle.min.js"></script>
	<script src="${pageContext.request.contextPath}/js/bootstrap.min.js"></script>
</body>
</html>