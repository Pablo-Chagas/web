<jsp:directive.page contentType="text/html; charset=UTF-8" />
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Novo Comentário - Facebook CRUD</title>
	<link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css"/>
</head>
<body>
	<div class="container">
		<div class="row mt-3">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<h1>Adicionar Comentário</h1>
			
				<form action="${pageContext.request.contextPath}/comments/insert" method="POST">
				      <!-- O post_id fica escondido aqui, pois já sabemos em qual post estamos a comentar -->
				      <input type="hidden" name="post_id" value="${post_id}">
				      
				      <div class="mb-3">
				      	<label for="content_id" class="form-label">O seu comentário:</label>
				      	<textarea id="content_id" name="content" class="form-control" rows="3" required></textarea>	
				      </div>
				      
				      <div class="mb-3">
				      	<label for="user_id" class="form-label">Quem está a comentar?</label>
				      	<select id="user_id" name="user_id" class="form-select" required>
                            <option value="">Selecione o seu utilizador...</option>
                            <c:forEach var="u" items="${users_list}">
                                <option value="${u.getId()}">${u.getName()}</option>
                            </c:forEach>
                        </select>
				      </div>
					
					  <button type="submit" class="btn btn-primary">Comentar</button>
                      <a href="${pageContext.request.contextPath}/posts" class="btn btn-secondary">Cancelar</a>
				</form>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
</body>
</html>