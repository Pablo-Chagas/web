<jsp:directive.page contentType="text/html; charset=UTF-8" />
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Novo Post - Facebook CRUD</title>
	<link rel="stylesheet" href="${pageContext.request.contextPath}/css/bootstrap.min.css"/>
</head>
<body>
	<div class="container">
		<div class="row mt-3">
			<div class="col-md-2"></div>
			
			<div class="col-md-8">
				<h1>Criar Novo Post</h1>
			
                <!-- Repare que a action aponta para a rota de insert que criamos no Java -->
				<form action="${pageContext.request.contextPath}/posts/insert" method="POST">
				      
				      <!-- Campo para digitar o texto do post -->
				      <div class="mb-3">
				      	<label for="content_id" class="form-label">O que você está pensando?</label>
				      	<textarea id="content_id" name="content" class="form-control" rows="3" required></textarea>	
				      </div>
				      
				      <!-- AQUI ESTÁ O SELECT QUE O PROFESSOR PEDIU! -->
				      <div class="mb-3">
				      	<label for="user_id" class="form-label">Autor do Post:</label>
				      	<select id="user_id" name="user_id" class="form-select" required>
                            <option value="">Selecione um usuário...</option>
                            <!-- O forEach vai varrer a users_list que mandamos lá do Java -->
                            <c:forEach var="u" items="${users_list}">
                                <option value="${u.getId()}">${u.getName()}</option>
                            </c:forEach>
                        </select>
				      </div>
					
					  <button type="submit" class="btn btn-primary">Publicar</button>
                      <a href="${pageContext.request.contextPath}/posts" class="btn btn-secondary">Cancelar</a>
				</form>
			</div>
			
			<div class="col-md-2"></div>
		</div>
	</div>
</body>
</html>