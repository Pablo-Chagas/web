package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Comment;
import model.ModelException;
import model.Post;
import model.User;

public class MySQLCommentDAO implements CommentDAO {

	@Override
	public boolean save(Comment comment) throws ModelException {
		String sql = "INSERT INTO comments (content, post_id, user_id) VALUES (?, ?, ?)";
		
		try (Connection conn = MySQLConnectionFactory.getConnection();
			 PreparedStatement stmt = conn.prepareStatement(sql)) {
			
			stmt.setString(1, comment.getContent());
			stmt.setInt(2, comment.getPost().getId());
			stmt.setInt(3, comment.getUser().getId());
			
			return stmt.executeUpdate() > 0;
		} catch (SQLException e) {
			throw new ModelException("Erro ao salvar comentário", e);
		}
	}

	@Override
	public List<Comment> listByPost(int postId) throws ModelException {
		List<Comment> comments = new ArrayList<>();
		String sql = "SELECT * FROM comments WHERE post_id = ? ORDER BY comment_date ASC";
		
		try (Connection conn = MySQLConnectionFactory.getConnection();
			 PreparedStatement stmt = conn.prepareStatement(sql)) {
			
			stmt.setInt(1, postId);
			ResultSet rs = stmt.executeQuery();
			
			while (rs.next()) {
				Comment c = new Comment();
				c.setId(rs.getInt("id"));
				c.setContent(rs.getString("content"));
				c.setCommentDate(rs.getTimestamp("comment_date"));
				
				// Cria objetos vazios apenas com os IDs para referência
				Post p = new Post();
				p.setId(rs.getInt("post_id"));
				c.setPost(p);
				
				User u = new User();
				u.setId(rs.getInt("user_id"));
				c.setUser(u);
				
				comments.add(c);
			}
		} catch (SQLException e) {
			throw new ModelException("Erro ao listar comentários", e);
		}
		return comments;
	}

	// Os métodos abaixo são obrigatórios pela Interface, 
	// mas podemos deixá-los vazios por agora para simplificar.
	@Override
	public boolean update(Comment comment) throws ModelException { return false; }
	
	@Override
	public boolean delete(Comment comment) throws ModelException { return false; }
	
	@Override
	public List<Comment> listAll() throws ModelException { return new ArrayList<>(); }
	
	@Override
	public Comment findById(int id) throws ModelException { return null; }
}