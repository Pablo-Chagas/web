package model;

import java.sql.Timestamp;

public class Comment {
	
	private int id;
	private String content;
	private Timestamp commentDate;
	
	// Aqui estão os relacionamentos (chaves estrangeiras) que o professor pediu!
	private Post post; 
	private User user; 
	
	// Métodos Getters e Setters para aceder aos dados
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	public Timestamp getCommentDate() {
		return commentDate;
	}
	public void setCommentDate(Timestamp commentDate) {
		this.commentDate = commentDate;
	}
	
	public Post getPost() {
		return post;
	}
	public void setPost(Post post) {
		this.post = post;
	}
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
}