package controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.ModelException;
import model.Post;
import model.User;
import model.dao.DAOFactory;
import model.dao.PostDAO;
import model.dao.UserDAO;

@WebServlet(urlPatterns = {"/posts", "/posts/form", "/posts/insert", "/posts/delete", "/posts/update"})
public class PostsController extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		
		String action = req.getRequestURI();
		System.out.println("URL: " + action);
		
		switch (action) {
		case "/facebook/posts": {
			loadPosts(req);
			RequestDispatcher rd = req.getRequestDispatcher("/posts.jsp");
			rd.forward(req, resp);
			break;
		}
		case "/facebook/posts/form": {
			loadUsers(req); // Carrega os utilizadores para o <select>
			RequestDispatcher rd = req.getRequestDispatcher("/post_form.jsp");
			rd.forward(req, resp);
			break;
		}
		// Pode adicionar as rotas de update e delete aqui posteriormente
		default:
			String message = String.format("URL não suportada: '%s'.", action);
			System.out.println(message);
			throw new IllegalArgumentException(message);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		
		String action = req.getRequestURI();
		
		if ("/facebook/posts/insert".equals(action)) {
			// Aqui vamos receber os dados do formulário
			String content = req.getParameter("content");
			String userIdStr = req.getParameter("user_id"); // ID vindo do <select>
			
			if (content != null && userIdStr != null) {
				Post post = new Post();
				post.setContent(content);
				
				User user = new User();
				user.setId(Integer.parseInt(userIdStr));
				post.setUser(user);
				
				PostDAO dao = DAOFactory.createDAO(PostDAO.class);
				try {
					dao.save(post);
				} catch (ModelException e) {
					e.printStackTrace();
				}
			}
			// Redireciona de volta para a lista
			resp.sendRedirect(req.getContextPath() + "/posts");
		}
	}
	
	private void loadPosts(HttpServletRequest req) {
		PostDAO dao = DAOFactory.createDAO(PostDAO.class);
		List<Post> posts = List.of();
		try {
			posts = dao.listAll();
		} catch (ModelException me) {
			me.printStackTrace();
		}
		req.setAttribute("posts_list", posts);
	}
	
	// Novo método para carregar os utilizadores para a tag <select>
	private void loadUsers(HttpServletRequest req) {
		UserDAO dao = DAOFactory.createDAO(UserDAO.class);
		List<User> users = List.of();
		try {
			users = dao.listAll();
		} catch (ModelException me) {
			me.printStackTrace();
		}
		req.setAttribute("users_list", users);
	}
}