package controller;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Comment;
import model.ModelException;
import model.Post;
import model.User;
import model.dao.CommentDAO;
import model.dao.DAOFactory;
import model.dao.UserDAO;

@WebServlet(urlPatterns = {"/comments/form", "/comments/insert"})
public class CommentsController extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		
		String action = req.getRequestURI();
		
		if (action.endsWith("/comments/form")) {
			// Carrega os utilizadores para a tag <select> do formulário de comentários
			UserDAO userDao = DAOFactory.createDAO(UserDAO.class);
			try {
				req.setAttribute("users_list", userDao.listAll());
			} catch (ModelException e) {
				e.printStackTrace();
			}
			
			// Pega o ID do post que veio na URL e envia para a página
			String postId = req.getParameter("post_id");
			req.setAttribute("post_id", postId);
			
			RequestDispatcher rd = req.getRequestDispatcher("/comment_form.jsp");
			rd.forward(req, resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		
		String action = req.getRequestURI();
		
		if (action.endsWith("/comments/insert")) {
			String content = req.getParameter("content");
			String userIdStr = req.getParameter("user_id");
			String postIdStr = req.getParameter("post_id"); // Precisamos saber em qual post estamos comentando
			
			if (content != null && userIdStr != null && postIdStr != null) {
				Comment comment = new Comment();
				comment.setContent(content);
				
				// Associa o utilizador ao comentário
				User user = new User();
				user.setId(Integer.parseInt(userIdStr));
				comment.setUser(user);
				
				// Associa o post ao comentário
				Post post = new Post();
				post.setId(Integer.parseInt(postIdStr));
				comment.setPost(post);
				
				CommentDAO dao = DAOFactory.createDAO(CommentDAO.class);
				try {
					dao.save(comment);
				} catch (ModelException e) {
					e.printStackTrace();
				}
			}
			// Depois de comentar, redireciona de volta para a lista de posts
			resp.sendRedirect(req.getContextPath() + "/posts");
		}
	}
}